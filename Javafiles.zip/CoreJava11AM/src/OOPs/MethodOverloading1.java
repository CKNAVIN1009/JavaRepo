package OOPs;

public class MethodOverloading1 {
public static void main(String[] args) {
	B b1=new B();
	b1.sum(1.5, 4.5);
	b1.sum(10, 20);
}
}
class B
{
	void sum(int x, int y)
	{
	int z=x+y;
	System.out.println("sum of int values are "+z);
	}
	void sum(double p, double q)
	{
	double r=p+q;
	System.out.println("Sum of double numbers are "+r);
	}
}
