package OOPs;

public class Dog
{
//data memebers
	String name="Tommy";
	String color;
	int height;
//method
	void jump()
	{
		System.out.println("Dog is jumping");
		System.out.println("Name of the dog is "+name);
	}
	void eating()
	{
		System.out.println("Dog is eatig");
	}
	public static void main(String[] args) {
		System.out.println("I am the body of main method");
		Dog d1=new Dog();//classname objectname=new classname();
		d1.jump();
		
	}
	
}

