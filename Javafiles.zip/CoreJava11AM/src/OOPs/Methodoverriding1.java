package OOPs;

public class Methodoverriding1 {
public static void main(String[] args) {
	Tiger t1=new Tiger();
	t1.eat();
	Animal t2=new Animal();
	t2.eat();
	Animal t3=new Tiger();
	t3.eat();
	//Tiger t4=new Animal(); Not possible
	
}
}
class Animal
{
	void eat()
	{
		System.out.println("Animal is eating");
	}
}
class Tiger extends Animal
{
	void eat()
	{
		System.out.println("Tiger is eating");
	}
}
