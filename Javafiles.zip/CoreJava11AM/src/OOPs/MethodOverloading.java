package OOPs;

public class MethodOverloading {
public static void main(String[] args) {
	A a1=new A();
	a1.sum(10, 20);
	a1.sum(10, 20, 30);
}
}
class A
{
	void sum(int a, int b)
	{
		int c=a+b;
		System.out.println("Sum of two numbers are "+c);
	}
	void sum(int x, int y, int z)
	{
		int p=x+y+z;
		System.out.println("Sum of three numbers are "+p);
	}
}
