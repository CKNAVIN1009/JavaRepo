package OOPs;

public class Abstraction {
	public static void main(String[] args) {
		Kumar k1=new Kumar();
		k1.eat();
		k1.drink();
		Naveen n1=new Kumar();
		n1.eat();
		n1.drink();
	}

}
abstract class Naveen
{
	void eat()
	{
	  System.out.println("Non abstract method is eating");	
	}
	abstract void drink();
}

class Kumar extends Naveen
{
	void drink()
	{
		System.out.println("Abstract mehthod is called");
	}
	
}
