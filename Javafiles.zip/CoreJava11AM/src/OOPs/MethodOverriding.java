package OOPs;

public class MethodOverriding 
{
public static void main(String[] args) {
	Hi h1=new Hi();
	h1.calculate(10);
	Hello h2=new Hello();
	h2.calculate(10);
	//Hello h3=new Hi(); Reference object is not going to access child mehtod
	//h3.calculate(10);
	Hi h4=new Hello();
	h4.calculate(10);
}
}
class Hi
{
   void calculate(int x) //same method with x as argument
   {
      int square=x*x;
      System.out.println("The square value of x is "+square);
   }
}
class Hello extends Hi
{
    void calculate(int x)  //same method with x as argument
     {
      int cube=x*x*x;
       System.out.println("The cube value of x is "+cube);
     }
}