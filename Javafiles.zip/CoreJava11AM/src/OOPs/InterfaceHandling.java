package OOPs;

public class InterfaceHandling {
	public static void main(String[] args) {
		Anyclass a1=new Anyclass();
		a1.m4();
		a1.m1();
		a1.m2();
		a1.m3();
		//I1 ii2=new I1();//Cannot create the object
		I1 ii3=new Anyclass();
		ii3.m1();
		ii3.m2();
		ii3.m3();
		//ii3.m4();//method not exist
		
		
	}

}
interface I1
{
 void m1(); //abstract method
 void m2();  //abstract method
 abstract void m3();
  
}
class Anyclass implements I1
{
	public void m2()
	{
		System.out.println("M2 method-abstact");
	}
	public void m1()
	{
		System.out.println("M1 method-abstract");
	}
	public void m3()
	{
		System.out.println("M3 method-abstract");
	}
	void m4()
	{
		System.out.println("M4 method-Nonabstract");
	}
	
	
}
