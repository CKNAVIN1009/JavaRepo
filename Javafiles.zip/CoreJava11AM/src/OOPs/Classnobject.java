package OOPs;

public class Classnobject {
public static void main(String[] args) {
	HumanBeing h1=new HumanBeing();
	h1.eat();
	h1.walk();
	System.out.println(h1.height);
	HumanBeing h2=new HumanBeing();
	h2.walk();
}
}
class HumanBeing
{
	//data members
	int weight=75;
	int height=175;
	String name="Human1";
	//method
	void eat()
	{
		System.out.println("I am eating");
	}
	void walk()
	{
		System.out.println("I am walking");
	}
}
