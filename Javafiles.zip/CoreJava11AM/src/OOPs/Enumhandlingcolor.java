package OOPs;

public enum Enumhandlingcolor {
	White, Black, ORange, Yellow

}
