package OOPs;

public class Encapsulationhandling {
//data private
	private int empid;
	public void setEmpid(int eid)
	{
		empid=eid;
	}
	public int getEmpid()
	{
		return empid;
	}
	public static void main(String[] args) {
		Encapsulationhandling e1=new Encapsulationhandling();
		e1.setEmpid(101);
	System.out.println(e1.getEmpid());
	}
}
