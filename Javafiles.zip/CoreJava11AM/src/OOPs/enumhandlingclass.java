package OOPs;

public class enumhandlingclass {
public static void main(String[] args) {
	System.out.println(Enumhandlingcolor.Black);
}
}
