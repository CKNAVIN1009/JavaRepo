package OOPs;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class Mismatchfile {
public static void main(String[] args) throws IOException {
	System.out.println("Hello");
	Path file1=Files.createTempFile("hfile1", ".doc");
	Path file2=Files.createTempFile("hfile2", ".doc");
	Files.writeString(file1, "Hello worl");
	Files.writeString(file2, "Hello worlderserfsdrds");
	long result=Files.mismatch(file1, file2);
    System.out.println(result);
    if(result>-1L)
    {
    	System.out.println("File mismatch");
    }
    else
    	System.out.println("File matched");

}
}
