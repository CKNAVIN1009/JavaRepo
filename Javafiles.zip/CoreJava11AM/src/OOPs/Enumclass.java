package OOPs;

public class Enumclass {
enum days {sunday, monday, tuesday, wednesday, thursday, friday, saturday}
public static void main(String[] args) {
	days day1=days.sunday,day2=days.monday;//you can assign other valuues also.
	System.out.println("The first day is "+day2.ordinal());
}
}
