package OOPs;

public class MultipleInheritanceViaInteraface {
public static void main(String[] args) {
	C1 obj=new C1();
	obj.sum();
	obj.sub();
	obj.mul();
	
}
}

interface A1
{
int x=10;
int y=30;
int z=x+y;
void sum();
}
interface B1
{
int a=10;
int b=50;
int c=a-b;
void sub();
}

class C1 implements A1, B1
{
public void sum()
{
System.out.println("sum of two numbers are "+z);
}
public void sub()
{
System.out.println("Subtraction of two numbers are "+c);
}
void mul()
{
int w=10;
int q=5;
int r=w*q;
System.out.println("multiplication of two numbers are "+r);
}
}