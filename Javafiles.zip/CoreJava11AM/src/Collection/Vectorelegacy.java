package Collection;
import java.util.*;

public class Vectorelegacy {
 public static void main(String[] args) {
	Vector v=new Vector();
	v.add(10);
	v.add("Naveen");
	v.add(10);
	v.add(null);
	v.add(null);
	v.add(null);
	v.add(null);
	v.add(null);
	v.add(null);
    v.add('g');
    v.add(null);
	v.add(null);
    v.setElementAt("hello", 3);
    System.out.println(v);
    System.out.println(v.capacity());
	
}
}
