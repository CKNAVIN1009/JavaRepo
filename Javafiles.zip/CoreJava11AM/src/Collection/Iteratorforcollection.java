package Collection;
import java.util.*;
import java.lang.*;

public class Iteratorforcollection {
	public static void main(String[] args) {
		List l=new ArrayList();
		l.add(100);
		l.add("Arun");
		l.add("Rahul");
		l.add(200);
		System.out.println(l);
		Iterator itr=l.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		l.remove(1);
		System.out.println(l);
		
		
	
		
	}

}
