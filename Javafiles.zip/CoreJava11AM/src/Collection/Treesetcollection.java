package Collection;
import java.util.*;

public class Treesetcollection {
public static void main(String[] args) {
	TreeSet ts=new TreeSet();
	ts.add(40);
	ts.add(10);
	ts.add(5);
	ts.add(45);
	ts.add(48);
	ts.add(40);
	System.out.println(ts);
	
}
}
