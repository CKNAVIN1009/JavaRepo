package Collection;
import java.util.*;

public class StackLegacy {
	public static void main(String[] args) {
		Stack s1=new Stack();
		s1.push("Naveen");
		s1.push(20);
		s1.push(25);
		System.out.println(s1);
		s1.add(1, 5);
		System.out.println(s1);
		s1.pop();
		System.out.println(s1);
		System.out.println(s1.peek());
		System.out.println(s1.search("Naveen"));
	
	}

}
