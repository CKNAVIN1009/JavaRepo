package Collection;
import java.util.*;

public class Linkedlistcollection {
	public static void main(String[] args) {
		ArrayList al1=new ArrayList();
		al1.add(20);
		al1.add("Naveen");
		LinkedList l1=new LinkedList(al1);
		l1.add(100);
		l1.add(250);
		System.out.println(l1);
	}

}
