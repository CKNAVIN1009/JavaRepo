package Collection;
import java.util.*;

public class Arraylistexample {
	public static void main(String[] args) {
		ArrayList al=new ArrayList();
		al.add(10);
		al.add(1, 20);
		al.add("Java");
		al.add(null);
		al.add('c');
		al.add("Java");
		al.add(null);
		ArrayList al1=new ArrayList(al);
		al1.add(30);
		System.out.println(al1);
		al1.clear();
		al1.add("naveen");
		System.out.println(al1);
		
		
		
	}

}
