package Collection;
import java.util.*;
//import java.lang.*;
public class ListIteratorexercise {
	public static void main(String[] args) {
		List l1=new ArrayList();
		l1.add("JAVA");
		l1.add(10);
		l1.add(20);
		System.out.println(l1);
		ListIterator lstr=l1.listIterator();
		while(lstr.hasNext())
		{
		System.out.println(lstr.next());	
		}
		lstr.set(500);
		System.out.println(l1);
		while(lstr.hasPrevious())
		{
			System.out.println(lstr.previous());
		}
		lstr.set(200);
		System.out.println(l1);
	
		
	}

	

}
