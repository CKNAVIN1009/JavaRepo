package Collection;
import java.util.*;


public class ListvsSet {
public static void main(String[] args) {
	ArrayList l1=new ArrayList();
	//l1.add(0, 120);
	l1.add(120);
	
	HashSet s1=new HashSet();
	s1.add(130);
	//s1.add(0, 130);Not an index bound
	
	l1.add(120);
	s1.add(130);

	l1.add(null);
	l1.add(null);
	//Iterator
	
	
	
	
	
	s1.add(null);
	s1.add(null);
	System.out.println(l1);
	System.out.println(s1);
	
	
	
	
	
	
}
}
