package Collection;
import java.util.*;

public class TreesetStringothers {
public static void main(String[] args) {
	TreeSet ts1=new TreeSet();
	ts1.add("Naveen");
	ts1.add("Rahul");
	ts1.add("Adarash");
	ts1.add("Naveen1");
	System.out.println(ts1);
	ts1.remove("Rahul");
	System.out.println(ts1);
	
}
}
