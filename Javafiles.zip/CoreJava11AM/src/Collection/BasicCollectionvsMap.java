package Collection;
import java.util.ArrayList;
import java.util.*;
public class BasicCollectionvsMap {
public static void main(String[] args) {
	ArrayList a1=new ArrayList();
	a1.add(10);
	a1.add("Arun");
	a1.add('N');

	HashSet h1=new HashSet();
	h1.add(11);
	
	List l1=new ArrayList();
	l1.add(20);
	Set s1=new HashSet();
	s1.add(40);
	
	
	
	
}
}
