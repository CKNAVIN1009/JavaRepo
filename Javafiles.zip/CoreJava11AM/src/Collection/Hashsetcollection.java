package Collection;
import java.util.*;

public class Hashsetcollection {
public static void main(String[] args) {
	
	HashSet hs=new HashSet();
	hs.add(10);
	hs.add("Naveen");
	hs.add(1);
	hs.add(45);
	hs.add(45);
	hs.add(40.5);
	hs.add(null);
	hs.add(5);
	ArrayList al=new ArrayList(hs);
	al.add(10);
	al.add("JAVA");
	al.add(null);
	//hs.add(4, 45);  No indexing concept.
	System.out.println(al);
	
}
}
