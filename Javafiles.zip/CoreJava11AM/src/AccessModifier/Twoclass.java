package AccessModifier;
import corejava.*;
class Twoclass {
	int a=10;
	private void hello()
	{
		System.out.println("Hello method");
	}
	public static void main(String[] args)
	{
		Twoclass t5=new Twoclass();
		t5.hello();
	}

}
