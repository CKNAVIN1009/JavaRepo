package AccessModifier;

public class Oneclass {
	String name="Naveen";
	void eat()
	{
		System.out.println("I am eating");
	}
   public static void main(String[] args) {
	Twoclass t2=new Twoclass();
	System.out.println(t2.a);
	
}
}
