package Scanner;

import java.util.Scanner;

public class ScannerInputfromUser {
public static void main(String[] args) {
	Scanner s=new Scanner(System.in);
	System.out.println("Enter your name: ");
	String name=s.next();
	System.out.println("Enter your roll Number: ");
	int roll=s.nextInt();
	System.out.println("Enter your gender");
	char gender=s.next().charAt(0);
	System.out.println("Enter your phone number: ");
	long phonenumber=s.nextLong();
	System.out.println("-----Welcome to the Report-----");
	System.out.println("Name of the student: "+name);
	System.out.println("Roll number of the student: "+roll);
	System.out.println("Gender of the student: "+gender);
	System.out.println("Contact number of student: "+phonenumber);
	System.out.println("-----End of the Report--------");
	
}
}
