package Wrapper;

public class WrapperclassexAutoboxing {
	public static void main(String[] args) {
		int i=10;
		//Integer ab=Integer.valueOf(i);  Manual flow
		Integer ab=i; //Autoboxing
		System.out.println(ab);
		System.out.println(i);
	}

}
