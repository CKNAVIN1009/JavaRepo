package Wrapper;

public class WrapperUnboxing {
	public static void main(String[] args) {
		Integer ab=new Integer(21);
		//int i=ab.intValue();
		int i=ab;
		System.out.println(i);
	}

}
