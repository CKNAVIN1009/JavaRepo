package Operators;

public class Comparisonoperator
{
   public static void main(String[] args)
   {
	  int x=20;
	  int y=20;
	  if(x==y) //comparision operator
	  {
		  System.out.println("Both are having same values");
	  }
	  else
		  System.out.println("Both are different values");
   }
}
