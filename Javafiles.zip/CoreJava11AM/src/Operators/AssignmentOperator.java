package Operators;

public class AssignmentOperator
{
   public static void main(String[] args)
   {
	  int x=100;
	  int y=200;
	  int z=x+y+200;
	  System.out.println("The value of z= "+z);
	  
   }
}
