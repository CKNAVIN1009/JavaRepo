package Operators;

public class Stringcontcat
{
  public static void main(String[] args)
  {
	int x=100;
	int y=200;
	int z=x+y;
	System.out.println(z);
	String p="100";
	String q="200";
	String r=p+q;
	System.out.println(r);
  }
}
