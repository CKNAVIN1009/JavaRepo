package Operators;

public class ArithmeticOperators
{
   public static void main(String[] args)
   {  
	 //addition
	 int a=10;
	 int b=20;
	 int c=a+b;
	 System.out.println("Addtion of two number are "+c);
	 //subtraction
	 int x=500;
	 int y=400;
	 int z=x-y;
	 System.out.println("Subtraction of two number is "+z);
	 //multiplication
	 int m1=10;
	 int m2=20;
	 int m3=m1*m2;
	 System.out.println("Multiplicaton of two mumber are "+m3);
	 //division
	 int d1=205;
	 int d2=100;
	 int d3=d1/d2;
	 System.out.println("Division of two numbers are "+d3);
	 //modulus
	 int md1=17;
	 int md2=5;
	 int md3=md1%md2;
	 System.out.println("Modulus shows remainder, so remainder is "+md3);
	 //increment
	 int i1=20;
	 System.out.println("Before increment value of i is "+i1);
	 int i2=++i1;
	 System.out.println("After increment value of 1 is "+i2);
	 //decrement
	 int dec1=30;
	 System.out.println("Before decrement value of d is "+dec1);
	 int dec2=--dec1;
	 System.out.println("After decrement value of d is "+dec2);
	  
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
   }
}
