package ControlStatement;

public class Decisionstatement
{
	public static void main(String[] args)
	{
       int a=20; 
       int b=30;
     //Simple if statement
       if(a<b) //20<30
       {
    	   System.out.println("A is lesser than B");
       }
     //if else statement
       int x=40;
       int y=20;
       if(x<y)//condition, 40<20
       {
    	  System.out.println("X is less than Y"); 
       }
       else
    	 System.out.println("x is greater than Y");  
     
	   }
}
