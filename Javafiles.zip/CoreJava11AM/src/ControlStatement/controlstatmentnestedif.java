package ControlStatement;

public class controlstatmentnestedif
{
   public static void main(String[] args)
   {
	int attendance=70;//condtion if attedance is more than 50, then only he /she will write exam
	if(attendance>50)//condition1
	{
		int marks=30;
		if(marks>40)//innercondition 2
		{
			System.out.println("Student has passed the exam");
		}
		else
		{
			System.out.println("Student has failed the exam");
		}
	}
	   
  }
}
