package ControlStatement;

public class Controlsatatment2
{
   public static void main(String[] args)
   {
	String subject="Maths";
	if(subject=="Science")//condition 1
	{
		System.out.println("Subject is Science");
	}
	else if(subject=="English") //condition 2
	{
		System.out.println("Subject is englis");
	}
	else if(subject=="social") //condition 3
	{
		System.out.println("Subject is social");
	}
	else 
		System.out.println("Subject is "+subject);
   }
}
