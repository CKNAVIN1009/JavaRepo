package ControlStatement;

public class Swtichstatement
{
  public static void main(String args[])
  {
	int number=0;
	//switch
	switch(number)
	{
	case 0:
		System.out.println("Number is matching that is: "+number);
	   break;
	case 1:
		System.out.println("Number is matching that is: "+number);
		break;
	case 2:
		System.out.println("Number is matching that is: "+number);
		break;
	default: 
	    System.out.println("I am a default statment and number is not matching that is: "+number);
	}
	
  }
  
}