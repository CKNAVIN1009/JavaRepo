package ControlStatement.LoopStatement;

public class starpattern4 {

}
