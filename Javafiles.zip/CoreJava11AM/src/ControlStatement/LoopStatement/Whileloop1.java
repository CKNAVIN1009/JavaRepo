package ControlStatement.LoopStatement;

public class Whileloop1
{
   public static void main(String[] args)
   {
	 int i=10;
	 while(i<=20)
	 {
		 System.out.println(i);
		 i++;
	 }
   }
}
