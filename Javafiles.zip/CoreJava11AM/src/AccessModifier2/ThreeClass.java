package AccessModifier2;
import AccessModifier.*;
import OOPs.*;
public class ThreeClass {
int a=20;
void sum()
{
	System.out.println("Sum of two numbers");
}
public static void main(String[] args) {
	Oneclass t3=new Oneclass();
	Dog d5=new Dog();
	
}
}
