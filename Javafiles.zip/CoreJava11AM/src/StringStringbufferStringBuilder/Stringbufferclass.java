package StringStringbufferStringBuilder;

public class Stringbufferclass {
public static void main(String[] args) {
	//1. StringBuffer sb=new StringBuffer();
	//System.out.println(sb.capacity());
	//2.  StringBuffer sb=new StringBuffer("Naveen");
	//System.out.println(sb.capacity());
	//3.  StringBuffer sb=new StringBuffer(1000);
	//System.out.println(sb.capacity());
	StringBuffer sb=new StringBuffer("Naveen Kumar");
	//System.out.println(sb.length());
	//System.out.println(sb.append("K"));
	//System.out.println(sb.length());
	//System.out.println(sb.charAt(2));
	//System.out.println(sb.delete(2, 5));
	//System.out.println(sb.deleteCharAt(1));
	System.out.println(sb.insert(2, "oooo"));
		
	
	
}
}
