package StringStringbufferStringBuilder;

public class StringBuilderclass {
	public static void main(String[] args) {
		StringBuffer sb=new StringBuffer();
		StringBuilder sb1=new StringBuilder();
				/*Almost all the methods are same, but the difference
		want to make it is "Synchronized method in Stringbuffer,where as 
		not synchronized in the Stringbuilder */
	}

}
