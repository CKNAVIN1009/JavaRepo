package StringStringbufferStringBuilder;

public class StringbufferclassEqual {
	public static void main(String[] args) {
		//String s1="Naveen";
		//String s2=s1.concat("Kumar");
		//System.out.println(s1.equals(s2));
		//System.out.println(s1);
		//System.out.println(s1.concat("Kumar"));
		StringBuffer s1=new StringBuffer();
		//StringBuffer s2=s1.append("Kumar");
		//System.out.println(s1.equals(s2));
		System.out.println(s1.capacity());
		s1.ensureCapacity(100);
		s1.append("hello");
		System.out.println(s1.capacity());
		s1.trimToSize();
		System.out.println(s1.capacity());
		
		
	}

}
