package LambdaExpression;

interface Hello
{
	void m1(int a, int b);
}


public class Lamdaexpression2 {
	public static void main(String[] args) {
		Hello h1=(int a, int b)->
		{
			System.out.println(a+b);
		};
		h1.m1(10, 20);
		Hello h2=(int a, int b)->
		{
			System.out.println(a*b);
		};
		h2.m1(10, 20);
	}

}
