package LambdaExpression;

interface I
{
	void m1();
	//void m2();
}

public class Lambdaexpression1  {
public static void main(String[] args) {
//how to write lamda expression for m1 method
	I ob=()->
			{
				System.out.println("I am a lambda for m1 method");
			};
		ob.m1();	
	
}
}
