package corejava;

public class Finalkeyword1 {
public static void main(String[] args) {
	 final int a=20;
	int b=a++;// a cant be incremented due to final keyword
	System.out.println("The value of b is "+b);
}
}
