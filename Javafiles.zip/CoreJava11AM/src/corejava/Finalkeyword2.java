package corejava;

public class Finalkeyword2 extends how {
	 void eat() //Final keyword
{
	System.out.println("I am eating");
}
public static void main(String[] args) {
	Finalkeyword2 f1=new Finalkeyword2();
	f1.eat();
}
}
class how
{
	final void eat()
	{
		System.out.println("I am eating-Final keyoword");
	}
}
