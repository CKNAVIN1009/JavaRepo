package corejava;

public class ThrowExample {
	static double division(double a, double b)
	{
		if(b==0)
		{
		  throw new ArithmeticException("divide by 0");
		  
		}
		return a/b;
		
	}

	public static void main(String[] args) {
		division(10, 2);
	}
}
