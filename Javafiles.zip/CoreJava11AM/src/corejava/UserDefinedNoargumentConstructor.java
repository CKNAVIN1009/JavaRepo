package corejava;

public class UserDefinedNoargumentConstructor {
      //Constructor
	 UserDefinedNoargumentConstructor()
	{
		System.out.println("I am no argument constructor");
	}
	public static void main(String[] args) {
		UserDefinedNoargumentConstructor u1=new UserDefinedNoargumentConstructor();
	}
}
