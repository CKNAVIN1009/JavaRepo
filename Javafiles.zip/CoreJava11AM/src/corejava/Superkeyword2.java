package corejava;

public class Superkeyword2 extends Parent {
 void m1()
 {
	 System.out.println("I am in child class");
 }
 void show()
 {
	 m1();
	 super.m1();
 }
 public static void main(String[] args) {
	 Superkeyword2 obj1=new Superkeyword2();
	 obj1.show();
}
}
class Parent
{
	void m1()
	{
		System.out.println("m1 method of parent class");
	}
}
