package corejava.Inheritance;

public class Hybrid {
	public static void main(String[] args) {
		Daughter d1=new Daughter();
		d1.mdaugther();
		d1.mf();
		d1.mgf();
		System.out.println(d1.w);
	}

}
class GrandFather
{
	int a=20;
	int b=30;
	void mgf()
	{
		System.out.println("I am granfather");
	}
}
class Father extends GrandFather
{
	int x=10;
	int y=20;
	void mf()
	{
		System.out.println("I am a father");
	}
}
class Son extends Father
{
	int p=10;
	int q=40;
	void mson()
	{
		System.out.println("I am son");
		
	}
}
class Daughter extends Father
{
	int w=50;
	int u=40;
	void mdaugther()
	{
		System.out.println("I am a daughter");
	}
}