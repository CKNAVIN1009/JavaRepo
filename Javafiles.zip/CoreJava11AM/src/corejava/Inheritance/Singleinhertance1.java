package corejava.Inheritance;

public class Singleinhertance1
{
public static void main(String[] args)
{
	Naveenclass n1=new Naveenclass();
	n1.run();
	n1.earn();
	n1.eat();
	
}
}
class HumanBeing
{
	int salary=30000;
	int weight;
	void eat()
	{
		System.out.println("Human Being is eating");
	}
}
class Naveenclass extends HumanBeing
{
	int age=30;
	String name="Naveen";
	void earn()
	{
		System.out.println("My salary is "+salary);
		System.out.println("I am earning");
	}
    void run()
    {
    	System.out.println("I am running");
    }
}