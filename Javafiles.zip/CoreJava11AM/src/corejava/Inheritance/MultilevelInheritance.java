package corejava.Inheritance;

public class MultilevelInheritance
{
public static void main(String[] args) {
	Son1 s1=new Son1();
	s1.mul();
	s1.sub();
	s1.sum();
}	

}
class Grand 
{
int x=10;
int y=20;
void sum()
{
int z=x+y;
System.out.println(z);
}
}

class Father1 extends Grand
{
int a=30;
int b=40;
void sub()
{
int c=b-a;
System.out.println(c);
}
}

class Son1 extends Father1
{
int p=20;
int q=2;
void mul()
{
int r=p*q;
System.out.println(r);
}
}

