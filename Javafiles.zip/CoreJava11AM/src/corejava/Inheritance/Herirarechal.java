package corejava.Inheritance;

public class Herirarechal {
	public static void main(String[] args) {
		System.out.println("This is from main()");
		child1 c1=new child1();
		c1.qualification();
		c1.property();
		child2 c2=new child2();
		c2.kid();
		c2.property();
	}
}
//Working with inheritance 
class Parent{
	//Data Members 
	String name="Father";
	
	//Data Methods 
	void property() {
		System.out.println("I have 3cr Property");
	}
}

// Creating child
class child1 extends Parent{
	//Data members
	int age=25;
	
	//Methods
	void qualification() {
		System.out.println("I Done my master in MCA");

	}
}
class child2 extends Parent{
	//Data members
	int age=12;
	
	//Methods
	void kid() {
		System.out.println("I'm a kid");

	}
}
