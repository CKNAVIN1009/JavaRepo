package corejava.Inheritance;

public class MultipleInheritanceNOTallowed {

}
class A
{
	int a=10;
}
class B
{
	int b=20;
}
class C extends A, B //Lets discuss solution in interface session
{
	int c=50;
}