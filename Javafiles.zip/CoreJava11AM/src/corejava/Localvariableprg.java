package corejava;

public class Localvariableprg {
//instance variable
int a=10;
int b=20;
void m1()
{
	//local variable
	int c=40;
	int d=c+b;
    System.out.println("Local variable is "+c);
    System.out.println("Value of d is "+d);
}
void m2()
{
	int e=10;
//	int f=e+c;  //local variable wil not be called outside the method
}
public static void main(String[] args) {
	Localvariableprg l1=new Localvariableprg();
	l1.m1();
}
}
