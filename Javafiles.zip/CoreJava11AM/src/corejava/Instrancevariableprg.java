package corejava;

public class Instrancevariableprg {
int a=10;
int b=20;
void m1()
{
	System.out.println(a);
}
public static void m2()
{
	// cant call instance variable in the in the static method
	//System.out.println(b);
}
public static void main(String[] args) {
	//Instrancevariableprg i1=new Instrancevariableprg();
	//i1.m1();

	
}
}
