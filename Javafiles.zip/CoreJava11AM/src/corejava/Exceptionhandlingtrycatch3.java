package corejava;

import java.io.FileInputStream;

public class Exceptionhandlingtrycatch3 {
public static void main(String[] args) {
	try
	{
	int a=10;
	System.out.println("Hello check");
	System.out.println("Try block is being read");
    FileInputStream fis=new FileInputStream("D:/UIFullstack/12.txt");//compile time exceptoin
    System.out.println("One try block is working");
    int b=10/0;
	}
	catch(ArithmeticException e)//subblock
	{
		System.out.println(e);
	}
	catch(Exception e)//parent block
	{
		System.out.println(e);
	}
}
}
