package corejava;

public class Typecasting
{
  public static void main(String args[])
  {
      //widenging type casting
	  int dataint=15;
	  double datadouble=dataint;  //automatically type casted(widening)
	  System.out.println("Lower data type: "+dataint);
	  System.out.println("Higher data type: "+datadouble);
      //widening type casting
	  double datadouble1=15.87d;
	  int dataint1=(int)datadouble1;
	  System.out.println("Higher data type: "+datadouble1);
	  System.out.println("Lower data type: "+dataint1);
  
  }
}
