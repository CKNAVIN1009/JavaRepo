package corejava;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ThrowsExample {
  static void readFile() throws IOException    
  {
	  FileReader fl=new FileReader("D:\\UIullstack\\1.txt");
       BufferedReader b1=new BufferedReader(fl);
       for(int LineNum=0;LineNum<4;LineNum++)
       {
    	   b1.readLine();
       }
       b1.close();
  }
  /* void callmethod() throws IOException
   {
	   readFile();
   }*/
   public static void main(String[] args) throws IOException {
	   readFile();
}
}
