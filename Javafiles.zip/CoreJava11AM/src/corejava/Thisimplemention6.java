package corejava;
//This can be used to return the current class instance from the method
public class Thisimplemention6 {
	Thisimplemention6 m1()
	{
		return this;

	}
	public static void main(String[] args) {
		Thisimplemention6 t6=new Thisimplemention6();
		t6.m1();
	}
	
	
}
