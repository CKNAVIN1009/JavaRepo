package corejava.Multithreading;

public class TestwithInteruptedThread13 extends Thread
{
	 public void run()
	 {   
		 System.out.println("Status is: "+Thread.interrupted());//False-->True
		 System.out.println(Thread.currentThread().isInterrupted());
		 //Thread.currentThread().interrupt();
		 System.out.println(Thread.currentThread().isInterrupted());
		 try
		 {
			 for(int i=1;i<5;i++)
			 {
				 System.out.println(i);
				 Thread.sleep(2000);
				Thread.currentThread().interrupt();
			 }
		 }
		 catch(Exception e)
		 {
			 System.out.println(e);
			 
		 }
	 }
  public static void main(String[] args) {
	  TestwithInteruptedThread13 t1=new TestwithInteruptedThread13();
	  t1.start();
	  System.out.println("--------mainthread----"+Thread.interrupted());
	  //t1.interrupt();
}
}
