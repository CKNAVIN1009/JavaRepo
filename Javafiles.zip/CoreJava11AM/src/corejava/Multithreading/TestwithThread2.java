package corejava.Multithreading;
//Thread with the help of runnable interface
public class TestwithThread2 implements Runnable {
	//override method
	public void run()
	{
		System.out.println("Thread task implmented");
	}
	public static void main(String[] args) {
		TestwithThread2 t1=new TestwithThread2();
		Thread th=new Thread(t1);
		th.start();
	
	}

}
