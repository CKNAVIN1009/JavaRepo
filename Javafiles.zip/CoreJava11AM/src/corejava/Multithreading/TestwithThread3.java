package corejava.Multithreading;

public class TestwithThread3 extends Thread {
public void run() //task1
{
	System.out.println("Thread task executed");
}
public static void main(String[] args) {
	TestwithThread3 t1=new TestwithThread3();
	t1.start();
	TestwithThread3 t2=new TestwithThread3();
	t1.start();

}
}
