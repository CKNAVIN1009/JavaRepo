package corejava.Multithreading;

public class TeswithDaemonThread extends Thread {
public void run()
{
	System.out.println(Thread.currentThread().isDaemon());
	if(Thread.currentThread().isDaemon()==true)
	{
	System.out.println("This is Daemon task");
    }
	else
		System.out.println("This is not a daemont task");
  }
public static void main(String[] args) {
	System.out.println("This is main thread");
	TeswithDaemonThread t1=new TeswithDaemonThread();
	t1.start();
	TeswithDaemonThread t2=new TeswithDaemonThread();
	t2.setDaemon(true);
	t2.start();
	
}
}

