package corejava.Multithreading;

public class Testwithsleepmethodthread8 extends Thread{
public void run()
{
	for(int i=1;i<=5;i++)
	{
		try {
			Thread.sleep(20000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(i);

	}
}
public static void main(String[] args) {
	Testwithsleepmethodthread8 t=new Testwithsleepmethodthread8();
	t.start();
}
}
