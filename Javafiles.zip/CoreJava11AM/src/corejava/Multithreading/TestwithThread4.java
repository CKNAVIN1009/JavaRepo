package corejava.Multithreading;
//This is for multiple task with multiple threads
class Test1 extends Thread
{
	public void run()
	{
		System.out.println("Task 1 executed by:  "+Thread.currentThread().getName());
	}
}
class Test2 extends Thread
{
	public void run()
	{
		System.out.println("Task 2 is executed by: "+Thread.currentThread().getName());
	}
}

public class TestwithThread4 {
	public static void main(String[] args) {
		System.out.println("Hello:  "+Thread.currentThread().getName());
		Thread.currentThread().setName("RohitThread");
		System.out.println(Thread.currentThread().getName());
		Test1 t1=new Test1();
		t1.start();
		System.out.println(Thread.currentThread().isAlive());
		Test1 t2=new Test1();
		t2.start();
		Test2 t3=new Test2();
		
		t3.start();
		Test2 t4=new Test2();
		t4.start();
		
	}

}
