package corejava.Multithreading;

public class TestwithPrioritythread5 extends Thread {
  public void run()
  {
	  System.out.println("Child thread");
  }
  public static void main(String[] args) {
	  System.out.println(Thread.currentThread().getPriority());
	  Thread.currentThread().setPriority(8);
	  System.out.println(Thread.currentThread().getPriority());
	  TestwithPrioritythread5 t=new TestwithPrioritythread5();
	  System.out.println(t.getPriority());
	  t.setPriority(9);
	  System.out.println(t.getPriority());
	  t.start();
}
}
