package corejava.Multithreading;

public class Testwithsleepthread7 extends Thread {
	public void run()
	{
		System.out.println("How are you");
		try {
			Thread.sleep(40000);
		
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("I am doing great");
	}
    public static void main(String[] args) {
    	Testwithsleepthread7 t=new Testwithsleepthread7();
    	t.start();
    
	}

}
