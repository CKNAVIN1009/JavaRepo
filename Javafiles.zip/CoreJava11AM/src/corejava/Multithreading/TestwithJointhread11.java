package corejava.Multithreading;

public class TestwithJointhread11 extends Thread{
	static Thread mainthread;
 public void run()
 {  
	 try
	 {   
		 mainthread.join();
		 for(int i=1;i<=5;i++)
		 {
			 System.out.println("Child thread: "+i);
		     Thread.sleep(3000); 
		 }
	 }
	 catch(Exception e)
	 {
		 System.out.println(e);
	 }
 }
 public static void main(String[] args) throws InterruptedException {
	 mainthread=Thread.currentThread();
	 TestwithJointhread11 t=new TestwithJointhread11();
	//Thread.currentThread().join();
	t.start();
    
	//t.join();
	try
	{
		for(int i=1;i<=5;i++)
		 {
			 System.out.println("Main thread: "+i);
		     Thread.sleep(3000); 
		 }
	}
		catch(Exception e)
		{
			System.out.println(e);
		}
	
	
	
}
}
