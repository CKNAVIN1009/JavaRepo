package corejava.Multithreading;

class MedicalExamination extends Thread
{
	public void run()
	{
		
		try
		{
			System.out.println("Medical examination started");
			Thread.sleep(3000);
			System.out.println("Medical examination completed");
	    }
		catch (InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
	    }
	}
}
class TestDrive extends Thread
{
	public void run()
	{
		
		try
		{
			System.out.println("TestDrive started");
			Thread.sleep(3000);
			System.out.println("TestDrive completed");
		}
		catch (InterruptedException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
     }
}
	class LicenceRelease extends Thread
	{
		public void run()
		{
			
			try 
			{
				System.out.println("Release is started");
				Thread.sleep(3000);
				System.out.println("Release is  completed");
			} catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	}

public class TestwithJoinThread12 {
	public static void main(String[] args) throws InterruptedException {
		MedicalExamination m1=new MedicalExamination();
		m1.start();
		m1.join();
		TestDrive t1=new TestDrive();
		t1.start();
		t1.join();
		LicenceRelease l1=new LicenceRelease();
		l1.start();
	}
}


