package corejava.Multithreading;
//Thread with help of Thread class
public class TestwithThread1 extends Thread
{
  public void run()
  {
	  System.out.println("This is my thread task");
  }
	
public static void main(String[] args) {
	TestwithThread1  t1=new TestwithThread1();
	t1.start();
}
}
