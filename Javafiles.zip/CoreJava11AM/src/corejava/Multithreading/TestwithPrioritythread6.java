package corejava.Multithreading;

public class TestwithPrioritythread6 extends Thread {
  public void run()
  {
	  System.out.println("child thread");
	  
  }
  public static void main(String[] args) {
	  System.out.println(Thread.currentThread().getPriority());
	  TestwithPrioritythread6 t1=new TestwithPrioritythread6();
	  Thread.currentThread().setPriority(MIN_PRIORITY);
      System.out.println(Thread.currentThread().getPriority());
      t1.start();
      TestwithPrioritythread6 t2=new TestwithPrioritythread6();
      System.out.println(t2.getPriority());
  }
}
