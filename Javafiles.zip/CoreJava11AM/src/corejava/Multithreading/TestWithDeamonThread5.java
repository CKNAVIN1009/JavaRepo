package corejava.Multithreading;

public class TestWithDeamonThread5 extends Thread{
public void run()
{
	System.out.println("I am a normal thead");
	System.out.println(Thread.currentThread().getName());
}
public static void main(String[] args) {
	  System.out.println("I am a main thread");
	//System.out.println("How are you");
	TestWithDeamonThread5 t1=new TestWithDeamonThread5();
    t1.setDaemon(true);
	t1.start();
	TestWithDeamonThread5 t2=new TestWithDeamonThread5();
	t2.setDaemon(false);
	t2.start();
}
}

