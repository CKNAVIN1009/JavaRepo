package corejava.Multithreading;

class BookTheaterSeat
{
	int total_seats=20;
	synchronized void bookSeat(int seats)
	{  
		System.out.println("-----------------------------");
		if(total_seats>=seats)
		{
			System.out.println(seats+" Ticket booked successfully");
			total_seats=total_seats-seats;
			System.out.println("Seats left now: "+total_seats);
		}
		else
		{
			System.out.println("Sorry, seats are not available");
			System.out.println("Only available seats are: "+total_seats);
		}
	}
}

public class TestwithSyncronization extends Thread
{
  static BookTheaterSeat b;
  int seats;
  public void run()
  {
	  b.bookSeat(seats);
  }
  public static void main(String[] args) {
	b=new BookTheaterSeat();
	TestwithSyncronization vardhan=new TestwithSyncronization();
	vardhan.seats=5;
	vardhan.start();
	TestwithSyncronization aadi=new TestwithSyncronization();
	aadi.seats=10;
	aadi.start();
	
}
}
