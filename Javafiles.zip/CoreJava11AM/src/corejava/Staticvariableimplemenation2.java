package corejava;

public class Staticvariableimplemenation2 {
	int s=200;
	static int a=10;
	void method1()
	{
		int b=10;
		System.out.println(a +" " +b);
		System.out.println(++a);
		System.out.println(++b);
		int t=s+b;
		System.out.println(t);
	
		
	}
	public static void main(String[] args) {
		Staticvariableimplemenation2 obj=new Staticvariableimplemenation2();
		obj.method1();
		System.out.println(++a);
		
	
	
	}

}
