package corejava;

public class Superkeyword3 extends X {
	Superkeyword3()
	{
     // super();
	System.out.println("I am constructor of child class");	
	}
	public static void main(String[] args) {
		X s4=new Superkeyword3();
	}

}

class X
{
	X()
	{
		System.out.println("I am constrcutor of Parent class");
	}
}