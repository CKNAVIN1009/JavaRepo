package corejava;

public class Thiskeyword {
	public static void main(String[] args) {
	Test t=new Test();
	t.setValue(20);
	t.show();
	}
}
class Test
{
int i;//instance
void setValue(int i) //20
{
this.i=i;
}
void show()
{
System.out.println(i);
}
}
