package corejava;

public class Parameterizedconstructor {
	//instance variable
	int empid;
	String name;
	//creating parameterized constructor
	Parameterizedconstructor(int id, String n)
	{
	empid=id;
	name=n;
	}
	void display()
	{
	System.out.println("The employee id and names are "+empid +" and " +name);
	}

	public static void main(String arg [])
	{
    Parameterizedconstructor e1=new Parameterizedconstructor(1, "Naveen");
    Parameterizedconstructor e2=new Parameterizedconstructor(2, "Rahul");
	e1.display();
	e2.display();

	}
}
