	package corejava;
	//This can be used invoke the current class method also.
	
	public class Thisimplement2 {
		void display()
		{
			System.out.println("Hello");
		}
		void show()
		{
			this.display();
		}
		public static void main(String[] args) {
			Thisimplement2 t1=new Thisimplement2();
			t1.show();
		}
	
	}
