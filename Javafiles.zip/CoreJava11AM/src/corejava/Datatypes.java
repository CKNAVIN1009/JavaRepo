package corejava;
public class Datatypes
{
    public static void main(String args[])
    {
	    byte a=111;  //byte data type
    	short b=20;
    	int number=100;
    	long longnumber=66767676L;
    	float decimalnumber=56.78f;
    	double doubleno=454.45d;
	   System.out.println("My first java program");
	   System.out.println("Value of b = "+b);
	   System.out.println(a);
	   System.out.println(number);
	   System.out.println(longnumber);
	   System.out.println(decimalnumber);
	   System.out.println(doubleno);
    }
   
}

