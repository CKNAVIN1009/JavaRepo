package corejava;

public class StaticVariableimplementation {
	//instance
   int a=20;
	//static variable
	static int b=200;
	void m1()
	{   
		
		int c=a+10;
		int e=b+20;
	}
	static void m2()
	{
		 
		// int d=a+200; since a is instance variable
		int d=b+200;
	}
	public static void main(String[] args) {
		StaticVariableimplementation s1=new StaticVariableimplementation();
		System.out.println(s1.a);
		System.out.println(s1.b);
		System.out.println(b);
		System.out.println(StaticVariableimplementation.b);
		
	}

}
