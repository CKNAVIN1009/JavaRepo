package corejava;
class Naveen
{
	int a=10;
}
public class Superkeywod1 extends Naveen
{
	int a=20;
	void show(int a)//30
	{
		System.out.println(a);
		System.out.println(super.a);
		System.out.println(this.a);
	}
	public static void main(String[] args) {
		Superkeywod1 s1=new Superkeywod1();
		s1.show(30);
	}
}

