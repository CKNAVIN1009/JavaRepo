package corejava;

public class exeption_trycatch2 {
public static void main(String[] args) {
	try
	{
	int a=10;
	System.out.println("Hello check");
	int b=10/0;
	System.out.println("Try block is being read");
	
	}
	catch(Exception e)
	{
		System.out.println(e);
		System.out.println("Catch block is being read");
	}
}
}
