package corejava;
import java.io.FileInputStream;

public class exception_trycatch {
public static void main(String[] args) {
	try
	{
		FileInputStream fis=new FileInputStream("D:\\UIFullstack\\1.txt");//compile time exceptoin
	    System.out.println("My try block is catched");
	}
	catch(Exception e)
	{
		System.out.println(e);
		System.out.println("My catch block is catched");
	}
}
}
