package corejava;

public class DefaultConstructor {
	int a=10;
public static void main(String[] args) {
	DefaultConstructor d1=new DefaultConstructor();
	System.out.println("The value of a: "+d1.a);
}
}
