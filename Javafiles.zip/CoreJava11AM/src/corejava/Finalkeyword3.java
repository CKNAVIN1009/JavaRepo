package corejava;

public class Finalkeyword3 extends Parentclass{ //due to parent class as 'final', it can not be inherited
void m2()
{
	System.out.println("m2 method");
}
public static void main(String[] args) {
	Finalkeyword3 f2=new Finalkeyword3();
	f2.m1();
}
}


final class Parentclass
{
	void m1()
	{
		System.out.println("m1 method");
	}
}
