package corejava;

public class Thisimplment4 {
  void m1(Thisimplment4 this2)
  {
	  System.out.println("This is m1 method");
  }
  void m2()
  {
	  m1(this); 
	  System.out.println("this is m2 method");
  }
  public static void main(String[] args) {
	  Thisimplment4 this2=new Thisimplment4();
	  this2.m2();
}
}
