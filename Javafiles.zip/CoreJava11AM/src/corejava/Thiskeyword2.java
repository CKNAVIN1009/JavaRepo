package corejava;

public class Thiskeyword2 {
public static void main(String[] args) {
	Hi h1=new Hi();
	h1.cal1(100);
	h1.cal2();
}
}
class Hi
{
	int x;
	void cal1(int x)//100
	{
		this.x=x;
	}
    void cal2()
    {
    	int y=x+10;
    	System.out.println(y);
    }
}
