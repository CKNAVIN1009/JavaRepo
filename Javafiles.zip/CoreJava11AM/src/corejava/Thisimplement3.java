package corejava;
//This can be used to invoke the current class constructor.

public class Thisimplement3 {
	Thisimplement3()
	{
		System.out.println("This is no argument constructor");
	}
	Thisimplement3(int a)
	{   
		this();
		System.out.println("This is argument constructor");
	}
	public static void main(String[] args) {
		Thisimplement3 t4=new Thisimplement3();
		//t4.Thisimplement3(5);
	}
}
