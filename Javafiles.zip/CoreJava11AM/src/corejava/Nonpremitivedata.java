package corejava;

public class Nonpremitivedata
{
	public static void main(String args[])
	{
		String s="I";
		//System.out.print(s);
		String hello="wanted to learn java";
		System.out.print(s+" "+hello);
	}

}
