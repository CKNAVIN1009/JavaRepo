package corejava;

public class thisimplementation5 {
	void m1()
	{
		Testc t=new Testc(this);
	}
    public static void main(String[] args) {
    	thisimplementation5 this5=new thisimplementation5();
    	this5.m1();
	}
}
class Testc
{
   Testc(thisimplementation5 this5)
   {
	   System.out.println("Test constructor");
   }
}


	

