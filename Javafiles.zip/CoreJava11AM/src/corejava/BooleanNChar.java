package corejava;

public class BooleanNChar
{
   	public static void main(String args[])
   	{
   		boolean isclassunderstandable=true;
   		boolean isassignmentcomplete=false;
   		char grade='A';
   		char lastname='k';
   		int charvalue1=65;
   		char charvalue2=68;
   		char hellovalue3=78;
   		System.out.println(charvalue1);
   		System.out.println(charvalue2);
   		System.out.println(hellovalue3);
   		
   		System.out.println("Is the class understandable " +isclassunderstandable);
   		System.out.println("is the assignment completed " +isassignmentcomplete);
   		System.out.println("My grade in school was "+grade);
   		System.out.println("My last name is "+lastname);
   	}
}
