package corejava;

import java.io.FileInputStream;

public class ExceptionFinally4 {
	public static void main(String[] args) {
		FileInputStream fis;
		try
		{	System.out.println(1);
			fis=new FileInputStream("D:/UIFullstack/12.txt");//compile time exceptoin
			System.out.println(5/0);
			System.out.println("I wll not be running if terminates");
		    System.exit(15);//in case we wanted to make it as exception
		}
		catch(Exception e)
		{   System.out.println("Catch is running due to exception in try");
			System.out.println(e);
		} 
		finally
		{  fis.close();
		   System.out.println("Hello, I will be called for sure");
		}
	}

}