package corejava;
import java.io.FileInputStream;
//Getting this issue due to compile time error and runtime excption
public class Exception2 {
	public static void main(String[] args) {
		//FileInputStream fis=new FileInputStream("D:/UIFullstack/1.txt");//compile time exceptoin
		System.out.println(5/0); //runtime
	}

}
