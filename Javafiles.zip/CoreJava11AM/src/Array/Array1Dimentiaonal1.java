package Array;

public class Array1Dimentiaonal1 {
	public static void main(String[] args) {
		//int a[]=new int[10];
		int[] a= {1, 2, 10, 20, 30, 40, 50};
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
	}

}
