package Array;

public class TwoDarray1 {
	public static void main(String[] args) {
		int a[][]= {{10, 20, 30}, {20, 30, 20}, {30, 80}};
		//System.out.println(a);
		//System.out.println(a[0][1]);
		//System.out.println(a[1][0]);
		//System.out.println(a[3][3]);
	//	System.out.println(a[0].length);
		for(int i=0;i<a.length;i++)
		{
			for(int j=0;j<a[i].length;j++)
			{
				System.out.print(a[i][j]+ " ");
			}
			System.out.println();
			
		}
	
	}

}
