package Array;

public class Array1Dimentional {
public static void main(String[] args) {
	int a[]=new int[3];
	System.out.println("Hello Array");
	a[0]=10;
	a[1]=11;
	a[2]=12;
	//a[3]=14;  out of size/bound
	System.out.println("Hello Array");
}

}
